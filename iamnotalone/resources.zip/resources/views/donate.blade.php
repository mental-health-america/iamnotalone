@extends('layout.master')
@section('content')
    <div id="IynmQYRnfs">
        <script type="text/javascript" src="https://default.salsalabs.org/api/widget/template/5b26eb37-505d-436a-90c0-8e5276379511/?tId=IynmQYRnfs" ></script>
    </div>
@endsection