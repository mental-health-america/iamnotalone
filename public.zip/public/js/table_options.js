function showHideMenu(id) {
   $("#"+id).toggle();
}